
def trigger_breakpoint(owner=None):
    pass
